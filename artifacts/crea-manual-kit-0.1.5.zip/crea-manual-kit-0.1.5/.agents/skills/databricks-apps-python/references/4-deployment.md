# Deploying Databricks Apps

**Docs**: https://docs.databricks.com/dev-tools/databricks-apps/deploy · https://docs.databricks.com/dev-tools/bundles/apps (Asset Bundles form)

Three deployment options: Databricks CLI (simplest), Asset Bundles (multi-environment), or CLI commands (programmatic).

---

## Option 1: Databricks CLI

**Best for**: quick deployments, single environment.

### Step 1: Create app.yaml

```yaml
command:
  - "python"        # Adjust per framework — see table below
  - "app.py"

env:
  - name: DATABRICKS_WAREHOUSE_ID
    valueFrom: sql-warehouse
  - name: USE_MOCK_BACKEND
    value: "false"
```

### app.yaml Commands Per Framework

| Framework | Command |
|-----------|---------|
| Dash | `["python", "app.py"]` |
| Streamlit | `["streamlit", "run", "app.py"]` |
| Gradio | `["python", "app.py"]` |
| Flask | `["gunicorn", "app:app", "-w", "4", "-b", "0.0.0.0:8000"]` |
| FastAPI | `["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]` |
| Reflex | `["reflex", "run", "--env", "prod"]` |

### Excluded directories

When uploading via the SDK's `upload_folder()` / `upload_to_workspace()`, the following directories are automatically skipped to keep uploads fast:

`node_modules`, `__pycache__`, `.venv`, `venv`, `.tox`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `dist`, `build`, `.eggs`, `*.egg-info`

If you use `databricks workspace import-dir` directly, it does **not** apply these exclusions. Either clean the directory first or use the SDK upload functions instead.

### Step 2: Create and Deploy

`--overwrite` on `workspace import-dir` is required for redeploys — without it the CLI **silently skips files that already exist**, so your updated code never makes it to the workspace and the app keeps running the old version. Harmless on the first deploy.

```bash
# Create the app
databricks apps create <app-name>

# Upload source code (make sure to exclude node_modules, venv, etc.)
databricks workspace mkdirs /Workspace/Users/<user>/apps/<app-name>
databricks workspace import-dir . /Workspace/Users/<user>/apps/<app-name> --overwrite

# Deploy
databricks apps deploy <app-name> \
  --source-code-path /Workspace/Users/<user>/apps/<app-name>

# Add resources via UI (SQL warehouse, Lakebase, etc.)

# Check status and URL
databricks apps get <app-name>
```

### Redeployment

Use this recipe after the initial deploy, when you want a clean upload (stale files removed). On a first-ever deploy the `workspace delete` line errors because the directory doesn't exist yet — either run Step 2 first, or prefix the delete with ` 2>/dev/null || true` if you want this recipe to double as a clean deploy.

```bash
databricks workspace delete /Workspace/Users/<user>/apps/<app-name> --recursive
databricks workspace import-dir . /Workspace/Users/<user>/apps/<app-name> --overwrite
databricks apps deploy <app-name> \
  --source-code-path /Workspace/Users/<user>/apps/<app-name>
```

---

## Option 2: Databricks Asset Bundles (DABs)

**Best for**: multi-environment deployments (dev/staging/prod), version-controlled infrastructure.

**Recommended workflow**: deploy via CLI first to validate, then generate bundle config.

### Generate Bundle from Existing App

```bash
databricks bundle generate app \
  --existing-app-name <app-name> \
  --key <resource_key>
```

This creates:
- `resources/<key>.app.yml` — app resource definition
- `src/app/` — app source files including `app.yaml`

### Deploy with Bundles

```bash
# Validate
databricks bundle validate -t dev

# Deploy
databricks bundle deploy -t dev

# Start the app (required after deployment)
databricks bundle run <resource_key> -t dev

# Production
databricks bundle deploy -t prod
databricks bundle run <resource_key> -t prod
```

**Key difference from other resources**: environment variables go in `src/app/app.yaml`, not `databricks.yml`.

For complete DABs guidance, use the **databricks-dabs** skill.

---

## Option 3: CLI Commands

For CLI-based app lifecycle management, see [6-cli-approach.md](6-cli-approach.md).

---

## Post-Deployment

### Check Logs

```bash
databricks apps logs <app-name>
```

**Key patterns in logs**:
- `[SYSTEM]` — deployment status, file updates, dependency installation
- `[APP]` — application output, framework messages
- `Deployment successful` — app deployed correctly
- `App started successfully` — app is running
- `Error:` — check stack traces

### Verify

1. Access app URL (from `databricks apps get <app-name>`)
2. Check all pages load correctly
3. Verify data connectivity (look for backend initialization messages in logs)
4. Test user authorization flow if enabled

### Configure Permissions

- Set `CAN USE` for approved users/groups
- Set `CAN MANAGE` only for trusted developers
- Verify service principal has required resource permissions
