# Evidencia de HU — <change>

En HU adoptadas en 0.1.5, este archivo es una vista derivada del handoff vigente mediante
`scripts/crea/transiciones.py render`, con fuente/hash `derived_from`. Los apartados de abajo
indican el detalle que debe referenciar el contrato, sin un segundo estado editado por separado.
Las HU anteriores conservan su registro histórico sin reconstrucción retrospectiva.

## Inventario de objetos afectados

Canónico en `evidence.objects` del handoff autor; las fases siguientes referencian o actualizan
en nuevos intentos sin borrar historia. Renderizar en `docs/hu/<change>/evidencia.md`.
Cada objeto enlaza HU/change, object_id local estable, nombre/tipo, capas/capacidades o motivo
no-aplica, operación prevista/real, paths de código/configuración, criterios/reglas y evidencia.

Estados independientes: planned; implementation (not_started/implemented/not_applicable);
deployment (not_performed/evidenced/not_applicable); verification con objetivo code o
deployed_object y estado/recibos propios. No deducir despliegue por código ni verificación remota
por pruebas locales. Un estado acreditado exige referencias; no obliga a desplegar para cerrar
una HU documental o de código. No duplica specs ni representa linaje operativo de datos.

## 1. Solicitud y criterios
Solicitud, cambio OpenSpec seleccionado y criterios verificables.

## 2. Estado y coordinacion
Etapa actual; identificadores reales de planner/developer/tester/reviewer; rondas de correccion.
No afirmar ejecucion de agentes a partir de archivos de configuracion.

### Confirmaciones de planificacion
Artefactos presentados por planner y nueva solicitud humana para apply; confirmaciones
de explore/update cuando correspondan. No confundir con la aprobacion final de archivo.

## 3. Candidato revisado
Commit si existe, diff y archivos modificados/nuevos. Si no hay commit, conservar un diff
revisable y hashes de los archivos del candidato incluidos los no rastreados. La vista de pruebas excluye solo outputs generados declarados en docs/hu/<change>/pruebas/
y conserva recibo de exclusiones. No excluir codigo, tests, fixtures o criterios para estabilizar hashes.

## 4. Plan y resultados de pruebas
plan_id, candidate_digest, base/HEAD e inventario Git completo; enlaces a plan, resultados,
gate, recibos y resumen por intento. Comando, entorno, version/runtime, fecha y resultado por criterio. Guardar solo evidencia
permitida. Registrar failed/blocked/not_run y el motivo; no tratarlos como passed.

## 5. Revision y sync
Hallazgos, correcciones, resultado verify, specs sincronizadas y diff presentado.

## 6. Aprobacion humana de archivo y publicacion
Estado inicial: PENDIENTE. Registrar respuesta humana, fecha, cambio y candidato al recibirla.
Identificar expresamente si autoriza commit/push, remoto, rama feature, base y archivos incluidos.
Una aprobacion solo de archivo mantiene publicacion pendiente.
Si se modifica el candidato o las specs, invalidar esta aprobacion y revisar de nuevo.
Agregar la propia respuesta humana y metadatos previstos de archivo/publicacion no
invalida la aprobacion si no se alteran alcance, criterios ni resultados revisados.

## 7. Archivo y pendientes
Operacion ejecutada, ruta final del cambio y limitaciones. Indicar rama feature, base,
remoto y rutas aprobadas antes del commit. El resultado de commit/push y su SHA se entregan
en la respuesta final: no editar este registro despues solo para incluir su propio commit.
Registrar si la aprobacion incluye crear PR Azure, con repo, ramas y titulo/cuerpo.
ID/URL y verificacion del PR se entregan en la respuesta final; no hay merge ni deploy.

## 8. Configuracion y extensiones
Referencias de skills, agentes, MCP o pasos usados en esta HU; sin credenciales.

## 9. Responsabilidades de tareas
Developer completa implementacion/tests y entrega ready_for_test. Tester completa
ejecucion con recibos y entrega ready_for_review. Reviewer completa revision/verify
y cierre autorizado. Una casilla de ejecucion requiere evidencia, no existencia de codigo.

## 10. Contexto Azure DevOps opcional
Referenciar solicitud de entrada, recibo/snapshot y hashes bajo evidence/azure-devops/<fase>-<intento>. Registrar ID/revision, intervalo de observacion, rol, versiones CLI y cobertura completa/parcial/vacia/fallida/no disponible. No copiar logs ni credenciales. En Reviewer referenciar snapshot Planner y decision de reconciliacion material si corresponde; no fabricar handoff de salida antes de la lectura.
